import { Component, OnInit } from "@angular/core";

@Component({
  selector: 'warning-alert',
  templateUrl: './warningAlert.component.html',
  styleUrls: ['./warningAlert.component.css']
})
export class WarningAlertComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
}
